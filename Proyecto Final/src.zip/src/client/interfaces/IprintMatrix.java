package client.interfaces;

public interface IprintMatrix {
	public void print(float v[]);

	public void print(float m[][]);
}
